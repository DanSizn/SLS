core file for srt-live-server
