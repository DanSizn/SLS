description for config file.

https://github.com/Edward-Wu/srt-live-server/wiki/Directives
